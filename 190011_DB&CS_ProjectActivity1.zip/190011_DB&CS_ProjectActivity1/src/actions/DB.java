package actions;

import java.sql.Connection;
import java.sql.DriverManager;

public class DB {
	
	 Connection conn=null;
	java.sql.PreparedStatement pst;
	public static Connection dbconnect() {
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");

	      // variables
	      final String url = "jdbc:mysql:///pets";
	      final String user = "root";
	      final String password = "#Sharma@1358";
	      
	      // establish the connection
	      Connection conn = DriverManager.getConnection(url, user, password);
	      if (conn == null) {
		         System.out.println("JDBC connection is not established");
		        
		      } else
		         System.out.println("Congratulations," + 
		              " JDBC connection is established successfully.\n");
		      // close JDBC connection
		      
	      
		return conn;
		}
		catch(Exception e2) {
			System.out.println(e2);
			return null;
		}
		
		
	}

}
